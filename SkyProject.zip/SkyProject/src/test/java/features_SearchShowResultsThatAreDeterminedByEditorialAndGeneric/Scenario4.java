package features_SearchShowResultsThatAreDeterminedByEditorialAndGeneric;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.DealsPage;
import pages.HomePage;
import utilities.ExcelReader;

public class Scenario4 extends BaseClass {
	
	HomePage homePage;
	DealsPage dealsPage;
	
	@BeforeClass
	  public void setup() throws IOException {
		browserInitialization();
		homePage = new HomePage();
		dealsPage = new DealsPage();
		excel = new ExcelReader(excelFilePath);
		logger= report.createTest("Scenario4");
	  }
	
	
  @Test
  public void userIsOnHomePage() {
	  userNavigatesHomePage();
	  homePage.acceptCookies();
  }
  
  @Test(dependsOnMethods = "userIsOnHomePage")
  public void userSearchKeyword() {
	  homePage.userSearch(excel.getExcelData("TestData", "Scenario4", "Keyword"));
  }
  
  @Test(dependsOnMethods = "userSearchKeyword")
  public void userVerifyEditorialSection() {
	  homePage.verifyEditorialSection();
  }
  
}
