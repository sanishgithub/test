package features_ShopPageIsNavigableAndUsable;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.DealsPage;
import pages.HomePage;
import utilities.ExcelReader;

public class Scenario3_UserSeeListOfDealsInDealsPage extends BaseClass {
	
	HomePage homePage;
	DealsPage dealsPage;
	
	@BeforeClass
	  public void setup() throws IOException {
		browserInitialization();
		homePage = new HomePage();
		dealsPage = new DealsPage();
		excel = new ExcelReader(excelFilePath);
		logger= report.createTest("Scenario3_UserSeeListOfDealsInDealsPage");
	  }
	
	
  @Test
  public void userIsOnHomePage() {
	  userNavigatesHomePage();
	  homePage.acceptCookies();
  }
  
  @Test(dependsOnMethods = "userIsOnHomePage")
  public void userNavigatesToDealsPage() {
	  homePage.userClickDeals();
	  homePage.acceptCookies();
  }
  
  @Test(dependsOnMethods = "userNavigatesToDealsPage")
  public void verifyUserSeeListOfDealsWithPrice() {
	  dealsPage.verifyPriceInDeals();
  }
}
