package features_ShopPageIsNavigableAndUsable;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.HomePage;
import pages.SignInPage;
import utilities.ExcelReader;

public class Scenario2_UserSeesTilesOnShopPage extends BaseClass {

	HomePage homePage;
	SignInPage signInPage;

	@BeforeClass
	public void setup() throws IOException {
		browserInitialization();
		homePage = new HomePage();
		signInPage = new SignInPage();
		excel = new ExcelReader(excelFilePath);
		logger = report.createTest("Scenario2_UserSeesTilesOnShopPage");
	}

	@Test
	public void userIsOnHomePage() throws InterruptedException {
		userNavigatesHomePage();
		homePage.acceptCookies();
	}

	@Test(dependsOnMethods = "userIsOnHomePage")
	public void userSignInWithInvalidCred()  {
		homePage.userSignIn();
		homePage.acceptCookies();
		signInPage.enterInvalidCred(
				excel.getExcelData("TestData", "Scenario2_UserSeesTilesOnShopPage", "InvalidUsername"));
	}

	@Test(dependsOnMethods = "userSignInWithInvalidCred")
	public void verifyMessageForInvalidCred() {
		signInPage.verifyInvalidCredMessage(
				excel.getExcelData("TestData", "Scenario2_UserSeesTilesOnShopPage", "MessageInvalidCred"));
		switchBackFromIframe();
	}
}
