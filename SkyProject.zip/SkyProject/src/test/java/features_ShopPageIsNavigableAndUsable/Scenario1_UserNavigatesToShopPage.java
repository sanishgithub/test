package features_ShopPageIsNavigableAndUsable;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import baseClass.BaseClass;
import pages.HomePage;
import utilities.ExcelReader;

public class Scenario1_UserNavigatesToShopPage extends BaseClass {
	
	HomePage homePage;
	
	@BeforeClass
	  public void setup() throws IOException {
		browserInitialization();
		homePage = new HomePage();
		excel = new ExcelReader(excelFilePath);
		logger= report.createTest("Scenario1_UserNavigatesToShopPage");
	  }
	
	
  @Test
  public void userIsOnHomePage()  {
	  userNavigatesHomePage();
	  homePage.acceptCookies();
  }
  
  @Test(dependsOnMethods = "userIsOnHomePage")
  public void userNavigatesToDealsPage() {
	  homePage.userClickDeals();
	  homePage.acceptCookies();
  }
  
  @Test(dependsOnMethods = "userNavigatesToDealsPage")
  public void verifyUserIsOnDealsPage() {
	  Assert.assertEquals(getCurrentPageURL(), 
			  excel.getExcelData("TestData", "Scenario1_UserNavigatesToShopPage" , "DealsLink"));
  }
}
