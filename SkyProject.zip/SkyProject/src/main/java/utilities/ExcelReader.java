package utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
//import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelReader {
	FileInputStream fis;
	XSSFWorkbook workBook;
	XSSFSheet sheet;
	XSSFCell cell;
	XSSFRow row;
	
	public ExcelReader(String path) throws IOException {
		fis = new FileInputStream(path);
		workBook = new XSSFWorkbook(fis);
	}
	
	public String getExcelData(String sheetName, String testID, String columnName) {
		XSSFSheet sheet = workBook.getSheet(sheetName);
		int rowIndex=0;
		int colIndex=0;
		
		int firstRow=sheet.getFirstRowNum();
		int lastRow=sheet.getLastRowNum();
		for (int rowCount = firstRow; rowCount <= lastRow; rowCount++) {
			if (sheet.getRow(rowCount).getCell(0).getStringCellValue().contains(testID)) {
				rowIndex = rowCount;
			}
		}
		XSSFRow row = sheet.getRow(0);
		int firstCell=row.getFirstCellNum();
		int lastCell=row.getLastCellNum();
		for (int cellCount = firstCell; cellCount < lastCell; cellCount++) {
			if (row.getCell(cellCount).getStringCellValue().trim().equals(columnName)) {
				colIndex = cellCount;
			}
		}
		
		XSSFCell cell = sheet.getRow(rowIndex).getCell(colIndex);
		DataFormatter formatter = new DataFormatter();
		String cellData =formatter.formatCellValue(cell);
		return cellData;
	}
	
	
	
}
