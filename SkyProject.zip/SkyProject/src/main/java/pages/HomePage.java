package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import baseClass.BaseClass;

public class HomePage extends BaseClass {
	
	public HomePage() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath = "//iframe[@title='SP Consent Message']")
	public WebElement iframeCookies;
	@FindBy(xpath = "//button[text()='Agree']")
	public WebElement agreeBtn_Cookies;
	@FindBy(xpath = "//a[text()='Deals']")
	public WebElement dealsLnk;
	@FindBy(xpath = "//a[text()='Sign in']")
	public WebElement signInLnk;
	@FindBy(xpath = "//button[@id='masthead-search-toggle']")
	public WebElement searchBtn;
	@FindBy(xpath = "//div[contains(@class,'search-input')]/input")
	public WebElement searchTxtBx;
	@FindBy(xpath = "//div[@id='search-results-container']")
	public WebElement searchResults;
	
	public void acceptCookies() {
		waitForFrameAndSwitch(iframeCookies);
		agreeBtn_Cookies.click();
		switchBackFromIframe();
	}
	
	public void userClickDeals() {
		dealsLnk.click();
	}
	
	public void userSignIn() {
		signInLnk.click();
		
	}
	
	public void userSearch(String keyword) {
		searchBtn.click();
		searchTxtBx.sendKeys(keyword);
	}
	
	public void verifyEditorialSection() {
		waitForElementVisible(searchResults);
		Assert.assertTrue(searchResults.isDisplayed());
	}
}
