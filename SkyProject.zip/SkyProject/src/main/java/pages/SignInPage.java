package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import baseClass.BaseClass;

public class SignInPage extends BaseClass {
	
	public SignInPage() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath = "//iframe[contains(@title,'Sky Sign-In')]")
	public WebElement frameCreateAccount;
	@FindBy(xpath = "//input[@id='username']")
	public WebElement userNameTxtBx;
	@FindBy(xpath = "//span[text()='Continue']")
	public WebElement continueBtn;
	@FindBy(xpath = "//div[contains(text(),'My Sky password')]")
	public WebElement createPasswordMsg;
	
	
	public void enterInvalidCred(String userName) {
		waitForFrameAndSwitch(frameCreateAccount);
		userNameTxtBx.sendKeys(userName);
		continueBtn.click();
	}
	
	public void verifyInvalidCredMessage(String message) {
		Assert.assertEquals(createPasswordMsg.getText(), message);
	}
	
	
}
