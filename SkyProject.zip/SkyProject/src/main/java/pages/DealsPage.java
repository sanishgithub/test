package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import baseClass.BaseClass;

public class DealsPage extends BaseClass {
	
	public DealsPage() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath = "//div[contains(@id,'deal')][contains(@class,'box')]")
	public List<WebElement> dealsList;
	@FindBy(xpath = "//span[contains(@id,'price')][contains(text(),'�')]")
	public List<WebElement> priceList;
	
	
	public void verifyPriceInDeals() {
		for (int i = 0; i < 3; i++) {
			Assert.assertTrue(priceList.get(i).getText().contains("�"));
		}
	}

	

	
	
}
