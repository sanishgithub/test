package baseClass;


import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.ExcelReader;
import java.time.LocalDate;


public class BaseClass {

	public static ThreadLocal<RemoteWebDriver> driver = new ThreadLocal<RemoteWebDriver>();
	public static ExtentReports report;
	public static ExtentTest logger;
	public static Properties prop;
	public ExcelReader excel;
	public String excelFilePath;
	
	public BaseClass() {
		prop = new Properties();
		try {
			FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+File.separator+
					"configuration"+File.separator+"config.properties");
			prop.load(fis);
			excelFilePath = System.getProperty("user.dir")+prop.getProperty("excelPath");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public void browserInitialization() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions option= new ChromeOptions();
	      // add Incognito parameter
		option.addArguments("--incognito");
	      // DesiredCapabilities object
//	      DesiredCapabilities cap = DesiredCapabilities.chrome();
	      //set capability to browser
//	      cap.setCapability(ChromeOptions.CAPABILITY, option);
		
		
		setDriver(new ChromeDriver(option));
		getDriver();
		getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		getDriver().manage().window().maximize();


	}
	
	public void userNavigatesHomePage()  {
		String url = prop.getProperty("URL");
		getDriver().get(url);
	}


	public void setDriver(RemoteWebDriver driverValue) {
		driver.set(driverValue);
	}

	public RemoteWebDriver getDriver() {
		return driver.get();
	}

	@AfterClass(alwaysRun = true)
	public void closeBrowser() {
		getDriver().quit();
	}
	
	@BeforeSuite
	public void reportSetUp() 
	{
//		For creating folder and html
		ExtentHtmlReporter extent=new ExtentHtmlReporter(new File(System.getProperty("user.dir")+"/Reports/ExtentSelenium.html"));
		report=new ExtentReports();
//		Attaching html to report
		report.attachReporter(extent);
	}
	
	public String captureScreenshot() throws Exception {
		Date date = new Date();
		String timestamp = "IMG"+date.getTime();
		String fileWithPath = System.getProperty("user.dir") + 
				"\\screenshots\\" + timestamp + ".png";
		TakesScreenshot scrShot = ((TakesScreenshot)getDriver());
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(fileWithPath);
		FileUtils.copyFile(SrcFile, DestFile);
		return fileWithPath;
	}

	@AfterMethod
	public void stepStatus(ITestResult result) {

		if (result.getStatus() == ITestResult.FAILURE)
		{
			try {
				logger.fail("Test Failed",MediaEntityBuilder.createScreenCaptureFromPath(captureScreenshot()).build());
			} catch (Exception e) {
				logger.log(Status.INFO, "StackTrace Result: " + Thread.currentThread().getStackTrace());
			}
		}
		else if(result.getStatus() == ITestResult.SUCCESS)
		{
			try {
				logger.pass("Test Passed");
			} catch (Exception e) {
			}
		}
		report.flush();
		//		Reporter.log("Test completed and report generated  ",true);
	}
	

	public void dropDownSelectionByValue(WebElement ele, String value) {
		Select dropDown = new Select(ele);
		dropDown.selectByValue(value);

	}

	public void dropDownSelectionByVisibleText(WebElement ele, String text) {
		Select dropDown = new Select(ele);
		dropDown.selectByVisibleText(text);

	}

	public void waitForFrameAndSwitch(WebElement element) {
		WebDriverWait wait = new WebDriverWait(getDriver(),60);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));
	}
	
	public void waitForElementVisible(WebElement element) {
		WebDriverWait wait = new WebDriverWait(getDriver(),60);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void switchToIframe(WebElement iFrame) {
		getDriver().switchTo().frame(iFrame);
	}

	public void switchBackFromIframe() {
		getDriver().switchTo().defaultContent();
	}

	public void switchToLastWindow() {
		for (String win : getDriver().getWindowHandles()) {
			getDriver().switchTo().window(win);
			getDriver().manage().window().maximize();
		}
	}

	public void switchToParentWindow(String parent) {
		getDriver().switchTo().window(parent);
	}

	public void forceClick(WebElement element) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click()", element);
	}

	public void scrollElementIntoView(WebElement element) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView();",element);
	}

	public void scroll(int x, int y) {
		((JavascriptExecutor) getDriver()).executeScript("window.scrollBy("+x+","+y+")");
	}

	public String getParentWindow() {
		String parent = null;
		parent=getDriver().getWindowHandle();
		return parent;
	}
	
	public String getCurrentPageURL() {
		return getDriver().getCurrentUrl();
	}
	



}
